[![Build Status](https://travis-ci.org/statgen/bamUtil.svg?branch=master)](https://travis-ci.org/statgen/bamUtil)

bamUtil
=======

These files provide some programs for working on SAM/BAM files.

To Build
--------

To use git to clone the required statgen library:

```
make cloneLib
```

Next, to build libStatGen & this program:

```
make
```

To install:

```
make install INSTALLDIR=pathToInstall
```