#ifndef _RECOVER_MANY_SPLICED_H
#define _RECOVER_MANY_SPLICED_H 1

#include "common.hpp"

using namespace std;

unsigned int recover_many_spliced(fusions_t& fusions, const unsigned int min_spliced_events);

#endif /* _RECOVER_MANY_SPLICED_H */
