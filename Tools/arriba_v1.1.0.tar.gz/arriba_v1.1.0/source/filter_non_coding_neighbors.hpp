#ifndef _FILTER_NON_CODING_NEIGHBORS_H
#define _FILTER_NON_CODING_NEIGHBORS_H 1

#include "common.hpp"

using namespace std;

unsigned int filter_non_coding_neighbors(fusions_t& fusions);

#endif /* _FILTER_NON_CODING_NEIGHBORS_H */
