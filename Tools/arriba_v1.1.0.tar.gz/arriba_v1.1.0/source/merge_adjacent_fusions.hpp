#ifndef _MERGE_ADJACENT_FUSIONS_H
#define _MERGE_ADJACENT_FUSIONS_H 1

#include "common.hpp"

using namespace std;

unsigned int merge_adjacent_fusions(fusions_t& fusions, const int max_distance);

#endif /* _MERGE_ADJACENT_FUSIONS_H */
