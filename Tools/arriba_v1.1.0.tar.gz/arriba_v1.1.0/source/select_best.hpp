#ifndef _SELECT_BEST_H
#define _SELECT_BEST_H 1

#include "common.hpp"

using namespace std;

unsigned int select_most_supported_breakpoints(fusions_t& fusions);

#endif /* _SELECT_BEST_H */
