#ifndef _FILTER_BOTH_INTRONIC_H
#define _FILTER_BOTH_INTRONIC_H 1

#include "common.hpp"

using namespace std;

unsigned int filter_both_intronic(fusions_t& fusions);

#endif /* _FILTER_BOTH_INTRONIC_H */
