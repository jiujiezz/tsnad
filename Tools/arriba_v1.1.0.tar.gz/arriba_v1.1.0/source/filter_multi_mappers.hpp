#ifndef _FILTER_MULTI_MAPPERS_H
#define _FILTER_MULTI_MAPPERS_H 1

#include "common.hpp"

using namespace std;

unsigned int filter_multi_mappers(chimeric_alignments_t& chimeric_alignments);

#endif /* _FILTER_MULTI_MAPPERS_H */
