#ifndef _FILTER_INCONSISTENTLY_CLIPPED_MATES
#define _FILTER_INCONSISTENTLY_CLIPPED_MATES 1

#include "common.hpp"

using namespace std;

unsigned int filter_inconsistently_clipped_mates(chimeric_alignments_t& chimeric_alignments);

#endif /* _FILTER_INCONSISTENTLY_CLIPPED_MATES */
