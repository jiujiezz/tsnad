#ifndef _RECOVER_BOTH_SPLICED_H
#define _RECOVER_BOTH_SPLICED_H 1

#include "common.hpp"

using namespace std;

unsigned int recover_both_spliced(fusions_t& fusions, const unsigned int max_fusions_to_recover);

#endif /* _RECOVER_BOTH_SPLICED_H */
