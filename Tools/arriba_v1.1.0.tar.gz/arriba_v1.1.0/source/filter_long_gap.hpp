#ifndef _FILTER_LONG_GAP_H
#define _FILTER_LONG_GAP_H 1

#include "common.hpp"

using namespace std;

unsigned int filter_long_gap(chimeric_alignments_t& chimeric_alignments);

#endif /* _FILTER_LONG_GAP_H */
