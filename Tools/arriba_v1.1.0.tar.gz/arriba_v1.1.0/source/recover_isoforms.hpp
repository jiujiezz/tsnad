#ifndef _RECOVER_ISOFORMS_H
#define _RECOVER_ISOFORMS_H 1

#include "common.hpp"

using namespace std;

unsigned int recover_isoforms(fusions_t& fusions);

#endif /* _RECOVER_ISOFORMS_H */
