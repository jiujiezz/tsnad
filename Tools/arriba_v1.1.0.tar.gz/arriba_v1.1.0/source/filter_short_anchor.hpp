#ifndef _FILTER_SHORT_ANCHOR_H
#define _FILTER_SHORT_ANCHOR_H 1

#include "common.hpp"

using namespace std;

unsigned int filter_short_anchor(fusions_t& fusions, unsigned int min_length);

#endif /* _FILTER_SHORT_ANCHOR_H */
